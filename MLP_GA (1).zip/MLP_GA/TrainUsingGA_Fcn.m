function [BestNetwork, BestCost, BestChart] = TrainUsingGA_Fcn(Xtr,Ytr,N,max_it,NumOfInputs,NumOfHiddens ,NumOfOutputs , Vmax, Vmin )

%% Network Structure
pr = [-1 1];
PR = repmat(pr,NumOfInputs,1);
Network = newff(PR,[NumOfHiddens NumOfOutputs],{'tansig' 'tansig'});
Network.trainparam.goal = .0001;

%% Problem Statement
ProblemParams.CostFuncName = 'CostFunction_Fcn';    % You should state the name of your cost function here.
CostFuncExtraParams.Network = Network;
CostFuncExtraParams.Xtr = Xtr;
CostFuncExtraParams.Ytr = Ytr;
ProblemParams.CostFuncExtraParams = CostFuncExtraParams;               % Reserved for the extra parameters in cost function. In normal application do not use it that is use [].

IW = Network.IW{1};
LW = Network.LW{2};
b = Network.b{1};
ProblemParams.NPar =  numel(IW) + numel(LW) + numel(b);                          % Number of optimization variables of your objective function. "NPar" is the dimention of the optimization problem.
ProblemParams.VarMin = Vmin ;                         % Lower limit of the optimization parameters. You can state the limit in two ways. 1)   2)
ProblemParams.VarMax = Vmax;                       % Lower limit of the optimization parameters. You can state the limit in two ways. 1)   2)

% Modifying the size of VarMin and VarMax to have a general form
if numel(ProblemParams.VarMin)==1
    ProblemParams.VarMin=repmat(ProblemParams.VarMin,ProblemParams.NPar,1);
    ProblemParams.VarMax=repmat(ProblemParams.VarMax,ProblemParams.NPar,1);
end

ProblemParams.SearchSpaceSize = ProblemParams.VarMax - ProblemParams.VarMin;


dim=ProblemParams.NPar ;
%% Creation of Initial Particles


BestChart=zeros(1,max_it);
X = GenerateNewPop(N , ProblemParams);
Positions=X';
nVar=dim;             % Number of Decision Variables

VarSize=[1 nVar];   % Decision Variables Matrix Size

VarMin=Vmin;         % Lower Bound of Variables
VarMax= Vmax;         % Upper Bound of Variables


%% GA Parameters

MaxIt=max_it;     % Maximum Number of Iterations

nPop=N;       % Population Size

pc=0.7;                 % Crossover Percentage
nc=2*round(pc*nPop/2);  % Number of Offsprings (also Parnets)
gamma=0.4;              % Extra Range Factor for Crossover

pm=0.3;                 % Mutation Percentage
nm=round(pm*nPop);      % Number of Mutants
mu=0.1;         % Mutation Rate

% Select method 100-010-001 only one mehod selection
UseRouletteWheelSelection=0;
UseTournamentSelection=1;
UseRandomSelection=0;


if UseRouletteWheelSelection
    beta=8; % Selection Pressure
end

if UseTournamentSelection
    TournamentSize=3;   % Tournamnet Size
end

pause(0.01); % Due to a bug in older versions of MATLAB

%% Initialization

empty_individual.Position=[];
empty_individual.Cost=[];

pop=repmat(empty_individual,nPop,1);

    % Initialize Position
%     Position=initialization(SearchAgents_no,dim,ub,lb);
for i=1:nPop
    
    pop(i).Position=Positions(i,:);
    % Evaluation
    if isempty(ProblemParams.CostFuncExtraParams)
       pop(i).Cost = feval(ProblemParams.CostFuncName,pop(i).Position');
    else
       pop(i).Cost = feval(ProblemParams.CostFuncName,pop(i).Position',ProblemParams.CostFuncExtraParams);
    end
        
end

% Sort Population
Costs=[pop.Cost];
[Costs, SortOrder]=sort(Costs);
pop=pop(SortOrder);

% Store Best Solution
BestSol=pop(1);

% Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);

% Store Cost
WorstCost=pop(end).Cost;

%% Main Loop

for it=1:MaxIt
    
    % Calculate Selection Probabilities
    if UseRouletteWheelSelection
        P=exp(-beta*Costs/WorstCost);
        P=P/sum(P);
    end
    
    % Crossover
    popc=repmat(empty_individual,nc/2,2);
    for k=1:nc/2
        
        % Select Parents Indices
        if UseRouletteWheelSelection
            i1=RouletteWheelSelection(P);
            i2=RouletteWheelSelection(P);
        end
        if UseTournamentSelection
            i1=TournamentSelection(pop,TournamentSize);
            i2=TournamentSelection(pop,TournamentSize);
        end
        if UseRandomSelection
            i1=randi([1 nPop]);
            i2=randi([1 nPop]);
        end

        % Select Parents
        p1=pop(i1);
        p2=pop(i2);
        
        % Apply Crossover
        [popc(k,1).Position, popc(k,2).Position]=Crossover(p1.Position,p2.Position,gamma,VarMin,VarMax);
        
        % Evaluate Offsprings
%     if isempty(ProblemParams.CostFuncExtraParams)
%        popc(k,1).Cost = feval(ProblemParams.CostFuncName,popc(k,1).Position');
%        popc(k,2).Cost = feval(ProblemParams.CostFuncName,popc(k,2).Position');

%     else
       popc(k,1).Cost = feval(ProblemParams.CostFuncName,popc(k,1).Position',ProblemParams.CostFuncExtraParams);
       popc(k,2).Cost = feval(ProblemParams.CostFuncName,popc(k,2).Position',ProblemParams.CostFuncExtraParams);

%     end
        
    end
    popc=popc(:);
    
    
    % Mutation
    popm=repmat(empty_individual,nm,1);
    for k=1:nm
        
        % Select Parent
        i=randi([1 nPop]);
        p=pop(i);
        
        % Apply Mutation
        popm(k).Position=Mutate(p.Position,mu,VarMin,VarMax);
        
        % Evaluate Mutant
        popm(k).Cost = feval(ProblemParams.CostFuncName,popm(k).Position',ProblemParams.CostFuncExtraParams);

       
    end
    
    % Create Merged Population
    pop=[pop
         popc
         popm]; %#ok
     
    % Sort Population
    Costs=[pop.Cost];
    [Costs, SortOrder]=sort(Costs);
    pop=pop(SortOrder);
    
    % Update Worst Cost
    WorstCost=max(WorstCost,pop(end).Cost);
    
    % Truncation
    pop=pop(1:nPop);
    Costs=Costs(1:nPop);
    
    % Store Best Solution Ever Found
    BestSol=pop(1);
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.Cost;
    
    
end


BestChart=BestCost;
BestCost=pop(1).Cost;
BestNetwork = ConstructNetwork_Fcn(Network,pop(1).Position');
end % End of Algorithm